<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;

class GroupController extends Controller
{
    /**
     * Listar grupos do usuário autenticado
     * GET /api/groups
     * 
     * Retorna todos os grupos onde o usuário está associado:
     * - Grupos que ele criou (created_by = user.id)
     * - Grupos onde ele é membro (via tabela group_members)
     */
    public function index(Request $request)
    {
        try {
            $user = Auth::user();
            
            if (!$user) {
                return response()->json([
                    'message' => 'Usuário não autenticado'
                ], 401);
            }

            Log::info("Buscando grupos para usuário ID: {$user->id} ({$user->email})");

            // Buscar grupos de múltiplas formas:
            // 1. Grupos criados pelo usuário (created_by)
            // 2. Grupos onde o usuário é membro (via tabela group_members)
            // 3. Grupos onde o usuário tem atividades (group_activities)
            // 4. Grupos onde o usuário tem documentos (documents)
            // 5. Grupos onde o usuário tem medicamentos (medications)
            
            $createdGroups = DB::table('groups')
                ->where('created_by', $user->id)
                ->pluck('id')
                ->toArray();
            
            // Se não encontrou grupos criados, verificar se o campo created_by existe
            if (empty($createdGroups)) {
                try {
                    $hasCreatedBy = DB::select("SHOW COLUMNS FROM `groups` LIKE 'created_by'");
                    if (empty($hasCreatedBy)) {
                        Log::warning("Campo 'created_by' não existe na tabela groups");
                        // Tentar buscar por outro campo ou retornar todos os grupos
                    }
                } catch (\Exception $e) {
                    Log::warning("Erro ao verificar campo created_by: " . $e->getMessage());
                }
            }
            
            Log::info("Grupos criados pelo usuário {$user->id}: " . count($createdGroups) . " - IDs: " . implode(', ', $createdGroups));

            // Buscar grupos via tabela pivot group_members (se existir)
            $memberGroups = [];
            try {
                if (Schema::hasTable('group_members')) {
                    $memberGroups = DB::table('group_members')
                        ->where('user_id', $user->id)
                        ->pluck('group_id')
                        ->toArray();
                    Log::info("Grupos via group_members para usuário {$user->id}: " . count($memberGroups) . " - IDs: " . implode(', ', $memberGroups));
                } else {
                    Log::info("Tabela group_members não existe");
                }
            } catch (\Exception $e) {
                Log::warning("Erro ao buscar group_members: " . $e->getMessage());
            }

            // Buscar grupos via atividades
            $activityGroups = [];
            try {
                if (Schema::hasTable('group_activities')) {
                    $activityGroups = DB::table('group_activities')
                        ->where('user_id', $user->id)
                        ->distinct()
                        ->pluck('group_id')
                        ->toArray();
                    Log::info("Grupos via atividades para usuário {$user->id}: " . count($activityGroups) . " - IDs: " . implode(', ', $activityGroups));
                }
            } catch (\Exception $e) {
                Log::warning("Erro ao buscar grupos via atividades: " . $e->getMessage());
            }

            // Buscar grupos via documentos
            $documentGroups = [];
            try {
                if (Schema::hasTable('documents')) {
                    $documentGroups = DB::table('documents')
                        ->where('user_id', $user->id)
                        ->distinct()
                        ->pluck('group_id')
                        ->toArray();
                    Log::info("Grupos via documentos para usuário {$user->id}: " . count($documentGroups) . " - IDs: " . implode(', ', $documentGroups));
                }
            } catch (\Exception $e) {
                Log::warning("Erro ao buscar grupos via documentos: " . $e->getMessage());
            }

            // Buscar grupos via medicamentos (se o usuário é médico)
            $medicationGroups = [];
            try {
                if (Schema::hasTable('medications')) {
                    $medicationGroups = DB::table('medications')
                        ->where('doctor_id', $user->id)
                        ->distinct()
                        ->pluck('group_id')
                        ->toArray();
                    Log::info("Grupos via medicamentos para usuário {$user->id}: " . count($medicationGroups) . " - IDs: " . implode(', ', $medicationGroups));
                }
            } catch (\Exception $e) {
                Log::warning("Erro ao buscar grupos via medicamentos: " . $e->getMessage());
            }

            // Combinar todos os IDs únicos
            $allGroupIds = array_unique(array_merge(
                $createdGroups,
                $memberGroups,
                $activityGroups,
                $documentGroups,
                $medicationGroups
            ));

            Log::info("Total de grupos únicos encontrados para usuário {$user->id}: " . count($allGroupIds) . " - IDs: " . implode(', ', $allGroupIds));
            
            // Se não encontrou nenhum grupo, logar para debug e retornar vazio
            if (empty($allGroupIds)) {
                Log::warning("Nenhum grupo encontrado para usuário {$user->id} ({$user->email})");
                try {
                    $allGroups = DB::table('groups')->pluck('id')->toArray();
                    Log::info("Total de grupos no sistema: " . count($allGroups));
                    if (count($allGroups) > 0) {
                        Log::warning("Existem " . count($allGroups) . " grupos no sistema, mas nenhum associado ao usuário {$user->id}");
                    }
                } catch (\Exception $e) {
                    Log::error("Erro ao contar grupos: " . $e->getMessage());
                }
                return response()->json([]);
            }

            // Buscar grupos completos com relacionamentos
            try {
                $groups = DB::table('groups')
                    ->whereIn('id', $allGroupIds)
                    ->get()
                    ->map(function ($group) use ($user) {
                    // Buscar informações do membro na tabela pivot (se existir)
                    $memberInfo = null;
                    $members = [];
                    
                    if (Schema::hasTable('group_members')) {
                        try {
                            $memberInfo = DB::table('group_members')
                                ->where('group_id', $group->id)
                                ->where('user_id', $user->id)
                                ->first();

                            // Buscar membros do grupo
                            $members = DB::table('group_members')
                                ->where('group_id', $group->id)
                                ->join('users', 'group_members.user_id', '=', 'users.id')
                                ->select(
                        'users.id as user_id',
                        'users.name',
                        'users.email',
                        'users.profile',
                        'group_members.role'
                    )
                    ->get()
                    ->map(function($m) {
                        return [
                            'user_id' => $m->user_id,
                            'name' => $m->name,
                            'email' => $m->email,
                            'profile' => $m->profile ?? null,
                            'role' => $m->role,
                            'is_admin' => ($m->role === 'admin')
                        ];
                    })
                    ->toArray();
                        } catch (\Exception $e) {
                            Log::warning("Erro ao buscar membros do grupo: " . $e->getMessage());
                        }
                    }

                    // Determinar se é criador
                    $isCreator = $group->created_by == $user->id;

                    // Construir resposta
                    $groupData = [
                        'id' => $group->id,
                        'name' => $group->name,
                        'description' => $group->description,
                        'accompanied_name' => $group->accompanied_name,
                        'accompanied_age' => $group->accompanied_age,
                        'accompanied_gender' => $group->accompanied_gender,
                        'accompanied_photo' => $group->accompanied_photo,
                        'health_info' => $group->health_info ? json_decode($group->health_info, true) : null,
                        'photo' => $group->photo,
                        'photo_url' => $group->photo ? url('storage/' . $group->photo) : null,
                        'code' => $group->code ?? null,
                'access_code' => $group->code ?? null,
                        'created_by' => $group->created_by,
                        'created_at' => $group->created_at,
                        'updated_at' => $group->updated_at,
                        // Informações do usuário atual no grupo
                        'is_creator' => $isCreator,
                        'is_admin' => $memberInfo ? ($memberInfo->role === 'admin') : false,
                        'role' => $memberInfo ? $memberInfo->role : null,
                        // Membros do grupo
                        'group_members' => $members,
                    ];

                        return $groupData;
                    })
                    ->values()
                    ->toArray();

                Log::info("Retornando " . count($groups) . " grupo(s) para usuário {$user->id}");

                return response()->json($groups);
            } catch (\Exception $e) {
                Log::error("Erro ao buscar grupos completos: " . $e->getMessage());
                Log::error("Stack trace: " . $e->getTraceAsString());
                
                // Retornar pelo menos os grupos criados mesmo se houver erro
                try {
                    $fallbackGroups = DB::table('groups')
                        ->whereIn('id', $createdGroups)
                        ->get()
                        ->map(function ($group) use ($user) {
                            return [
                                'id' => $group->id,
                                'name' => $group->name,
                                'description' => $group->description,
                                'is_creator' => true,
                                'is_admin' => false,
                                'created_by' => $group->created_by,
                            ];
                        })
                        ->values()
                        ->toArray();
                    
                    Log::info("Retornando grupos criados como fallback: " . count($fallbackGroups));
                    return response()->json($fallbackGroups);
                } catch (\Exception $fallbackError) {
                    Log::error("Erro no fallback: " . $fallbackError->getMessage());
                    return response()->json([
                        'message' => 'Erro ao buscar grupos',
                        'error' => $e->getMessage()
                    ], 500);
                }
            }
        } catch (\Exception $e) {
            Log::error("Erro ao buscar grupos: " . $e->getMessage());
            Log::error("Stack trace: " . $e->getTraceAsString());
            
            return response()->json([
                'message' => 'Erro ao buscar grupos',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Criar novo grupo
     * POST /api/groups
     */
    public function store(Request $request)
    {
        // Implementação do store se necessário
        // Por enquanto, retornar erro
        return response()->json([
            'message' => 'Método não implementado'
        ], 501);
    }

    /**
     * Obter detalhes de um grupo específico
     * GET /api/groups/{id}
     */
    public function show($id)
    {
        try {
            $user = Auth::user();
            
            if (!$user) {
                return response()->json([
                    'message' => 'Usuário não autenticado'
                ], 401);
            }

            // Buscar o grupo
            $group = DB::table('groups')->where('id', $id)->first();
            
            if (!$group) {
                return response()->json([
                    'message' => 'Grupo não encontrado'
                ], 404);
            }

            // Verificar se o usuário tem acesso ao grupo
            $hasAccess = false;
            
            // 1. Verificar se é criador
            if ($group->created_by == $user->id) {
                $hasAccess = true;
            }
            
            // 2. Verificar via group_members
            if (!$hasAccess && Schema::hasTable('group_members')) {
                $hasAccess = DB::table('group_members')
                    ->where('user_id', $user->id)
                    ->where('group_id', $id)
                    ->exists();
            }
            
            // 3. Verificar via atividades, documentos, medicamentos, etc.
            if (!$hasAccess) {
                $hasActivities = Schema::hasTable('group_activities') && 
                    DB::table('group_activities')
                        ->where('group_id', $id)
                        ->where('user_id', $user->id)
                        ->exists();
                
                $hasDocuments = Schema::hasTable('documents') && 
                    DB::table('documents')
                        ->where('group_id', $id)
                        ->where('user_id', $user->id)
                        ->exists();
                
                $hasMedications = Schema::hasTable('medications') && 
                    DB::table('medications')
                        ->where('group_id', $id)
                        ->where('user_id', $user->id)
                        ->exists();
                
                $hasAppointments = Schema::hasTable('appointments') && 
                    DB::table('appointments')
                        ->where('group_id', $id)
                        ->where('user_id', $user->id)
                        ->exists();
                
                $hasAccess = $hasActivities || $hasDocuments || $hasMedications || $hasAppointments;
            }
            
            if (!$hasAccess) {
                return response()->json([
                    'message' => 'Você não tem acesso a este grupo'
                ], 403);
            }

            // Buscar informações do membro
            $memberInfo = null;
            $members = [];
            
            if (Schema::hasTable('group_members')) {
                $memberInfo = DB::table('group_members')
                    ->where('group_id', $id)
                    ->where('user_id', $user->id)
                    ->first();

                $members = DB::table('group_members')
                    ->where('group_id', $id)
                    ->join('users', 'group_members.user_id', '=', 'users.id')
                    ->select(
                        'users.id as user_id',
                        'users.name',
                        'users.email',
                        'users.profile',
                        'group_members.role'
                    )
                    ->get()
                    ->map(function($m) {
                        return [
                            'user_id' => $m->user_id,
                            'name' => $m->name,
                            'email' => $m->email,
                            'profile' => $m->profile ?? null,
                            'role' => $m->role,
                            'is_admin' => ($m->role === 'admin')
                        ];
                    })
                    ->toArray();
            }

            $isCreator = $group->created_by == $user->id;

            $groupData = [
                'id' => $group->id,
                'name' => $group->name,
                'description' => $group->description,
                'accompanied_name' => $group->accompanied_name,
                'accompanied_age' => $group->accompanied_age,
                'accompanied_gender' => $group->accompanied_gender,
                'accompanied_photo' => $group->accompanied_photo,
                'health_info' => $group->health_info ? json_decode($group->health_info, true) : null,
                'photo' => $group->photo,
                'photo_url' => $group->photo ? url('storage/' . $group->photo) : null,
                'code' => $group->code ?? null,
                'access_code' => $group->code ?? null,
                'created_by' => $group->created_by,
                'created_at' => $group->created_at,
                'updated_at' => $group->updated_at,
                'is_creator' => $isCreator,
                'is_admin' => $memberInfo ? ($memberInfo->role === 'admin') : false,
                'role' => $memberInfo ? $memberInfo->role : null,
                'group_members' => $members,
            ];

            return response()->json($groupData);
        } catch (\Exception $e) {
            Log::error('Erro ao buscar grupo: ' . $e->getMessage());
            return response()->json([
                'message' => 'Erro ao buscar grupo',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Atualizar grupo
     * PUT /api/groups/{id}
     */
    public function update(Request $request, $id)
    {
        // Implementação do update se necessário
        return response()->json([
            'message' => 'Método não implementado'
        ], 501);
    }

    /**
     * Deletar grupo
     * DELETE /api/groups/{id}
     */
    public function destroy($id)
    {
        // Implementação do destroy se necessário
        return response()->json([
            'message' => 'Método não implementado'
        ], 501);
    }

    public function members($id) {
        try {
            $user = Auth::user();
            if (!$user) return response()->json(["success" => false, "message" => "Usuário não autenticado"], 401);
            $group = DB::table("groups")->where("id", $id)->first();
            if (!$group) return response()->json(["success" => false, "message" => "Grupo não encontrado"], 404);
            $hasAccess = $group->created_by == $user->id;
            if (!$hasAccess && Schema::hasTable("group_members")) {
                $hasAccess = DB::table("group_members")->where("user_id", $user->id)->where("group_id", $id)->exists();
            }
            if (!$hasAccess) return response()->json(["success" => false, "message" => "Você não tem acesso"], 403);
            $members = [];
            if (Schema::hasTable("group_members")) {
                $members = DB::table("group_members")->join("users", "group_members.user_id", "=", "users.id")->where("group_members.group_id", $id)->where("users.is_active", 1)->select("users.id", "users.name", "users.email", "users.phone", "users.photo", "users.photo_url", "users.profile", "group_members.role", "group_members.joined_at")->get()->map(function ($m) {
                    return ["id" => $m->id, "user_id" => $m->id, "name" => $m->name, "email" => $m->email, "phone" => $m->phone, "photo" => $m->photo, "photo_url" => $m->photo_url || ($m->photo ? url("storage/" . $m->photo) : null), "role" => $m->role, "is_admin" => ($m->role === "admin"), "profile" => $m->profile, "joined_at" => $m->joined_at];
                })->values()->toArray();
            }
            if ($group->created_by) {
                $found = false;
                foreach ($members as $m) {
                    if (($m["id"] ?? null) == $group->created_by || ($m["user_id"] ?? null) == $group->created_by) {
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    $creator = DB::table("users")->where("id", $group->created_by)->first();
                    if ($creator) {
                        $members[] = ["id" => $creator->id, "user_id" => $creator->id, "name" => $creator->name, "email" => $creator->email, "phone" => $creator->phone, "photo" => $creator->photo, "photo_url" => $creator->photo_url || ($creator->photo ? url("storage/" . $creator->photo) : null), "role" => "admin", "is_admin" => true, "profile" => $creator->profile, "joined_at" => $group->created_at];
                    }
                }
            }
            return response()->json(["success" => true, "data" => $members]);
        } catch (\Exception $e) {
            Log::error("Erro ao buscar membros: " . $e->getMessage());
            return response()->json(["success" => false, "message" => "Erro ao buscar membros", "error" => $e->getMessage()], 500);
        }
    }

}
